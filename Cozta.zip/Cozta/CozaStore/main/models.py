from django.db import models
from django.contrib.auth.models import User
from phonenumber_field.modelfields import PhoneNumberField
from django.utils.html import mark_safe
from easy_thumbnails.files import Thumbnailer




# ------------------------------------------------Home--------------------------------------------------------------

class Slider(models.Model):

   image = models.ImageField('Slider Image' , upload_to='media')

   title = models.CharField('Title', max_length=50)
   slug = models.CharField('Slug', max_length=50)

   def __str__(self):
      return self.title
   

   class Meta:
      verbose_name = 'Slider'
      verbose_name_plural = 'Sliders'



# -------------------------------------------------------------------------------------------------------------------












# ------------------------------------------------Blog --------------------------------------------------------------
class Tag(models.Model):

    name = models.CharField('Tag Name' , max_length=50)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Tag'
        verbose_name_plural = 'Tags'
    

class Comment(models.Model):
   comment = models.TextField()
   name = models.CharField('User Name', max_length=50)
   email = models.EmailField('User Email')
   website = models.URLField(max_length=255, blank=True)
   blog = models.ForeignKey('Blog', on_delete=models.CASCADE , related_name='blog_comment', null=True)

   def __str__(self) -> str:
      return self.name
   

   class Meta:

      verbose_name = "Comment"
      verbose_name_plural = "Comments"




class Blog(models.Model):
   date = models.DateField("Date")
   title = models.CharField("Title", max_length = 30)
   image = models.ImageField("Image", upload_to="media")
   description = models.TextField("Description" , null = True)
   assortment = models.CharField("Assortment", max_length=35)

   user = models.ForeignKey(User , verbose_name="Users", on_delete=models.CASCADE)
   tags = models.ManyToManyField(Tag)
   
   def __str__(self) -> str:
      return self.title
   
   def img_preview(self):
      return mark_safe(f'<img src="{self.image.url}" width="60px"/>')


   class Meta:
      verbose_name = "Blog"
      verbose_name_plural = "Blogs"


# --------------------------------------------------------------------------------------------------------------------

# ---------------------------------------------------About-Us-------------------------------------------------------------


class About(models.Model):

    title = models.CharField('Title', max_length=100)
    text = models.TextField('Text')
    image = models.ImageField('Image', upload_to='media')

    def __str__(self):
        return self.title

    class Meta:

      verbose_name = "About Us"
      verbose_name_plural = "About Us"


# --------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------Contact-Us----------------------------------------------------------------

class ContactUs(models.Model):
   email = models.EmailField('User Email')
   message = models.TextField('Message')

   def __str__(self):
       return self.email

   class Meta:
      verbose_name = 'ContactUs'  
      verbose_name_plural = 'ContactUs'   



class ContactInformation(models.Model):

   address = models.CharField('Store Address' , max_length=255)
   phone = PhoneNumberField()
   email = models.EmailField('Sale Support Email')

   def __str__(self):
       return self.address

   class Meta:
      verbose_name = 'Contact Information'
      verbose_name_plural = 'Contact Information'


# --------------------------------------------------------------------------------------------------------------------

# --------------------------------------------Shop--------------------------------------------------------------------

class Category(models.Model):

   name = models.CharField('Category Name', max_length=50)
   keyword = models.CharField("Short Keyword",max_length=15, null=True)
   image = models.ImageField(upload_to = "media", null=True)

   def __str__(self):
      return self.name

   class Meta:
      verbose_name = 'Category'
      verbose_name_plural = 'Categories'    


class Color(models.Model):

   name = models.CharField('Color Name', max_length=50)

   def __str__(self):
      return self.name

   class Meta:
      verbose_name = 'Color'
      verbose_name_plural = 'Colors'    


class Size(models.Model):

   name = models.CharField('Size Name', max_length=5)

   def __str__(self):
      return self.name

   class Meta:
      verbose_name = 'Size'
      verbose_name_plural = 'Sizes'    


class Image(models.Model):

   image = models.ImageField('Image', upload_to='media')

   def __str__(self):
      return super().__str__()
   
   class Meta:
      verbose_name = 'Image'
      verbose_name_plural = 'Images'    



class Product(models.Model):

   category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='prodcat')
   tags = models.ManyToManyField(Tag)
   colors = models.ManyToManyField(Color)
   sizes = models.ManyToManyField(Size)
   images = models.ManyToManyField(Image)
   # created_at = models.DateTimeField(auto_now_add = True , blank = True)


   name = models.CharField('Product Name', max_length=255)
   price = models.PositiveSmallIntegerField('Product Price')
   about = models.TextField(max_length=400)

   facebook = models.URLField('Facebook URL', blank=True)
   twitter = models.URLField('Twitter URL', blank=True)
   google = models.URLField('Google URL', blank=True)

   description = models.TextField('Product Description')


   def __str__(self):
      return self.name
      
   class Meta:
      verbose_name = 'Product'
      verbose_name_plural = 'Products'



class Review(models.Model):
   RATING_CHOICES = [
        (1,'1 - Poor'),
        (2,'2 - Fair'),
        (3,'3 - Good'),
        (4,'4 - Very good'),
        (5,'5 - Excellent'),
    ]


   rating = models.CharField(choices=RATING_CHOICES, max_length=50)
   text = models.TextField('Review Text')
   name = models.CharField('Name', max_length=50)
   email = models.EmailField('Email')
   product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='prodreview')


   def __str__(self):
      return self.name

   class Meta:
      verbose_name = 'Review'
      verbose_name_plural = 'Reviews'


# --------------------------------------------------------------------------------------------------------------------


# ----------------------------Search---------------------------------------------------------------
class Serach(models.Model):
   q = models.CharField( "q",max_length=100  , blank = True)
   # created_at = models.DateTimeField(auto_now_add = True , blank =True)


class Form(models.Model):
   q = models.CharField( "q",max_length=100  , blank = True)
   created_at = models.DateTimeField(auto_now_add = True , blank =True)